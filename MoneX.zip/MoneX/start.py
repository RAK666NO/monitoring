# auto_run.py
import subprocess
import sys
import os
import time
import webbrowser
import threading

def install_requirements():
    """Автоматическая установка необходимых библиотек"""
    required = ['requests', 'flask']
    for package in required:
        try:
            __import__(package)
            print(f"✅ {package} уже установлен")
        except ImportError:
            print(f"📦 Устанавливаю {package}...")
            subprocess.check_call([sys.executable, '-m', 'pip', 'install', package])
            print(f"✅ {package} установлен")

def run_server():
    """Запуск основного сервера"""
    try:
        # Запускаем ваш скрипт
        subprocess.run([sys.executable, 'proekt.py'])
    except Exception as e:
        print(f"Ошибка запуска: {e}")
        input("Нажмите Enter для выхода...")

def open_browser_delayed():
    """Открытие браузера с задержкой"""
    time.sleep(2)
    webbrowser.open('http://localhost:5000')

if __name__ == '__main__':
    print("=" * 50)
    print("   🚀 MoneX - Автозапуск")
    print("=" * 50)
    
    # Проверяем наличие основного файла
    if not os.path.exists('proekt.py'):
        print("❌ Ошибка: Файл proekt.py не найден!")
        print("Убедитесь, что этот скрипт находится в одной папке с proekt.py")
        input("\nНажмите Enter для выхода...")
        sys.exit(1)
    
    # Устанавливаем зависимости
    print("\n🔍 Проверка зависимостей...")
    install_requirements()
    
    print("\n🎯 Запуск сервера...")
    
    # Открываем браузер в отдельном потоке
    threading.Thread(target=open_browser_delayed, daemon=True).start()
    
    # Запускаем сервер
    run_server()